// 서버(폰/PC) 시간대와 상관없이 항상 한국시간 기준으로 계산
const KST_OFFSET_MS = 9 * 60 * 60 * 1000;

export type KstParts = { y: number; m: number; d: number; h: number; min: number };

export function kstNow(date = new Date()): KstParts {
  const k = new Date(date.getTime() + KST_OFFSET_MS);
  return {
    y: k.getUTCFullYear(),
    m: k.getUTCMonth() + 1,
    d: k.getUTCDate(),
    h: k.getUTCHours(),
    min: k.getUTCMinutes(),
  };
}

const pad = (n: number) => String(n).padStart(2, '0');

function shiftHours(date: Date, hours: number): Date {
  return new Date(date.getTime() + hours * 60 * 60 * 1000);
}

function fmt(p: KstParts, hh: number) {
  return { base_date: `${p.y}${pad(p.m)}${pad(p.d)}`, base_time: `${pad(hh)}00` };
}

/** 초단기실황: 매시 정시 기준, 발표 지연 감안해서 45분 전이면 이전 시각 사용 */
export function ncstBase(now = new Date()) {
  const p = kstNow(now);
  if (p.min < 45) {
    const prev = kstNow(shiftHours(now, -1));
    return fmt(prev, prev.h);
  }
  return fmt(p, p.h);
}

/** 단기예보: 02,05,08,11,14,17,20,23시 발표, 15분 여유 두고 가장 최근 발표분 */
export function vilageBase(now = new Date()) {
  const slots = [2, 5, 8, 11, 14, 17, 20, 23];
  const p = kstNow(now);
  const minutes = p.h * 60 + p.min;
  const usable = slots.filter((s) => s * 60 + 15 <= minutes);
  if (usable.length === 0) {
    // 00:00~02:14 → 전날 23시 발표분
    const prev = kstNow(shiftHours(now, -3));
    return fmt(prev, 23);
  }
  return fmt(p, usable[usable.length - 1]);
}
