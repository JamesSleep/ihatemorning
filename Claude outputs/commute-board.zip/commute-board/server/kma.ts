import { ncstBase, vilageBase } from './time.js';

const BASE = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0';

export type KmaItem = {
  baseDate: string;
  baseTime: string;
  category: string;
  nx: number;
  ny: number;
  obsrValue?: string; // 실황
  fcstDate?: string; // 예보
  fcstTime?: string;
  fcstValue?: string;
};

async function call(op: string, params: Record<string, string>, key: string): Promise<KmaItem[]> {
  // serviceKey는 "Decoding" 키를 넣어야 함 (URLSearchParams가 알아서 인코딩)
  const qs = new URLSearchParams({
    serviceKey: key,
    pageNo: '1',
    numOfRows: '1000',
    dataType: 'JSON',
    ...params,
  });
  const res = await fetch(`${BASE}/${op}?${qs}`, { signal: AbortSignal.timeout(10_000) }).catch((e) => {
    throw new Error(`KMA ${op} 연결 실패: ${e?.cause?.code ?? e?.message ?? e}`);
  });
  const text = await res.text();

  // 키 오류 등은 JSON이 아니라 XML로 옴
  if (!text.trim().startsWith('{')) {
    const msg = text.match(/<returnAuthMsg>(.*?)<\/returnAuthMsg>/)?.[1] ?? text.slice(0, 200);
    throw new Error(`KMA ${op} 오류: ${msg}`);
  }
  const json = JSON.parse(text);
  const header = json?.response?.header;
  if (header?.resultCode !== '00') {
    throw new Error(`KMA ${op} 오류: ${header?.resultCode} ${header?.resultMsg}`);
  }
  return json.response.body.items.item as KmaItem[];
}

/** 초단기실황: T1H 기온, RN1 1시간 강수량, REH 습도, PTY 강수형태, WSD 풍속 */
export function getUltraSrtNcst(key: string, nx: number, ny: number) {
  return call('getUltraSrtNcst', { ...ncstBase(), nx: String(nx), ny: String(ny) }, key);
}

/** 단기예보: POP 강수확률, PTY 강수형태, PCP 강수량, SNO 적설, TMN/TMX 최저/최고 등 */
export function getVilageFcst(key: string, nx: number, ny: number) {
  return call('getVilageFcst', { ...vilageBase(), nx: String(nx), ny: String(ny) }, key);
}
