// 아주 단순한 메모리 캐시. 갱신 실패하면 마지막 성공 값을 stale 표시와 함께 돌려줌
type Entry<T> = { value: T; at: number };

const store = new Map<string, Entry<unknown>>();

export type Cached<T> = { data: T; fetchedAt: string; stale: boolean; error?: string };

export async function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<Cached<T>> {
  const hit = store.get(key) as Entry<T> | undefined;
  if (hit && Date.now() - hit.at < ttlMs) {
    return { data: hit.value, fetchedAt: new Date(hit.at).toISOString(), stale: false };
  }
  try {
    const value = await fn();
    store.set(key, { value, at: Date.now() });
    return { data: value, fetchedAt: new Date().toISOString(), stale: false };
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    if (hit) return { data: hit.value, fetchedAt: new Date(hit.at).toISOString(), stale: true, error };
    throw e;
  }
}
